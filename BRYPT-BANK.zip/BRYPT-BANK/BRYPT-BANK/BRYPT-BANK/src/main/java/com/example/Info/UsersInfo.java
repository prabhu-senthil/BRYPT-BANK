package com.example.Info;

import java.util.Date;

public class UsersInfo {

	private Long id;
	private String name;
	private String email;
	private String password;
	private String gender;
	private int accountNo;
	
	
	private Date dob;
	public String accountType ;
	private String address;
	private int age;
	/* private String ifscCode="BRYPT04CARD"; */
	private long adharNo;
	private String panNo;
	private long phoneNo;
	private long balance;
	public UsersInfo() 
	{ 
		
	}
	public UsersInfo(Long id, String name, String email, String password, String gender, int accountNo, Date dob,
	String accountType, String address, int age, long adharNo, String panNo, long phoneNo, long balance)
	{
	super();
	this.id = id;
	this.name = name;
	this.email = email;
	this.password = password;
	this.gender = gender;
	this.accountNo = accountNo;
	this.dob = dob;
	this.accountType = accountType;
	this.address = address;
	this.age = age;
	this.adharNo = adharNo;
	this.panNo = panNo;
	this.phoneNo = phoneNo;
	this.balance = balance;
	}
	public Long getId() {
	return id;
	}
	public void setId(Long id) {
	this.id = id;
	}
	public String getName() {
	return name;
	}
	public void setName(String name) {
	this.name = name;
	}
	public String getEmail() {
	return email;
	}
	public void setEmail(String email) {
	this.email = email;
	}
	public String getPassword() {
	return password;
	}
	public void setPassword(String password) {
	this.password = password;
	}
	public String getGender() {
	return gender;
	}
	public void setGender(String gender) {
	this.gender = gender;
	}
	public int getAccountNo() {
	return accountNo;
	}
	public void setAccountNo(int accountNo) {
	this.accountNo = accountNo;
	}
	public Date getDob() {
	return dob;
	}
	public void setDob(Date dob) {
	this.dob = dob;
	}
	public String getAccountType() {
	return accountType;
	}
	public void setAccountType(String accountType) {
	this.accountType = accountType;
	}
	public String getAddress() {
	return address;
	}
	public void setAddress(String address) {
	this.address = address;
	}
	public int getAge() {
	return age;
	}
	public void setAge(int age) {
	this.age = age;
	}
	public long getAdharNo() {
	return adharNo;
	}
	public void setAdharNo(long adharNo) {
	this.adharNo = adharNo;
	}
	public String getPanNo() {
	return panNo;
	}
	public void setPanNo(String panNo) {
	this.panNo = panNo;
	}
	public long getPhoneNo() {
	return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
	this.phoneNo = phoneNo;
	}
	public long getBalance() {
	return balance;
	}
	public void setBalance(long balance) {
	this.balance = balance;
	}
	

}




