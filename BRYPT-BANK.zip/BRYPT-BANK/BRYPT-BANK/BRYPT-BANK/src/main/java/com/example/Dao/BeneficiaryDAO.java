package com.example.Dao;

import java.util.List;



import javax.persistence.EntityManager;



import javax.persistence.Query;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;



import com.example.Info.BeneficiaryInfo;
/*import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
*/
import com.example.classes.Beneficiary;



//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;






@Repository
public class BeneficiaryDAO {



@Autowired
private EntityManager entityManager;



public BeneficiaryDAO() {
}



public Beneficiary findById(Long beneficiaryid) { return
this.entityManager.find(Beneficiary.class, beneficiaryid); }



public List<BeneficiaryInfo> listBeneficiaryInfo() {
String sql = "Select new " + BeneficiaryInfo.class.getName() //
+ "(e.beneficiaryId,e.beneficiaryName,e.bank ,e.accountNo,e.phoneNo) " //
+ " from " + Beneficiary.class.getName() + " e ";
Query query = entityManager.createQuery(sql, BeneficiaryInfo.class);
return query.getResultList();
}
}





