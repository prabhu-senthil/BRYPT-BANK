package com.example.classes;

public class Balance {

	private long bankAccountId;
    
	 public Balance() {

	    }

	public Balance(long bankAccountId) {
		
		this.bankAccountId = bankAccountId;
	}

	public long getBankAccountId() {
		return bankAccountId;
	}

	public void setBankAccountId(long bankAccountId) {
		this.bankAccountId = bankAccountId;
	}


}
