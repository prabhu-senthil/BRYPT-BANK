package com.example.Info;

public class BeneficiaryInfo {
	private long beneficiaryId;
	private String beneficiaryName;
	private String bank;
	/* private double balance; */
	private long accountNo;
	private long phoneNo;
	public BeneficiaryInfo(long beneficiaryId, String beneficiaryName, String bank, long accountNo,
	long phoneNo) {
	super();
	this.beneficiaryId = beneficiaryId;
	this.beneficiaryName = beneficiaryName;
	this.bank = bank;
	/* this.balance = balance; */
	this.accountNo = accountNo;
	this.phoneNo = phoneNo;
	}
	public long getBeneficiaryId() {
	return beneficiaryId;
	} 
	public void setBeneficiaryId(long beneficiaryId) {
	this.beneficiaryId = beneficiaryId;
	}
	public String getBeneficiaryName() {
	return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
	this.beneficiaryName = beneficiaryName;
	} 
	public String getBank() {
	return bank;
	} 
	public void setBank(String bank) {
	this.bank = bank;
	} /*
	* public double getBalance() { return balance; }
	*
	* public void setBalance(double balance) { this.balance = balance; }
	*/
	public long getAccountNo() {
	return accountNo;
	} public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
	} public long getPhoneNo() {
	return phoneNo;
	} public void setPhoneNo(long phoneNo) {
	this.phoneNo = phoneNo;
	}
	}


	


