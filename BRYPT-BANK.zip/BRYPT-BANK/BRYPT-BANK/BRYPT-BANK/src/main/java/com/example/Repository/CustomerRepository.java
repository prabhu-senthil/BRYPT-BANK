
  package com.example.Repository;
  
  
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.classes.Users;
  
  public interface CustomerRepository extends JpaRepository<Users, Long> {
  
		
		 @Query("select c from Users c where  c.username like ?1") 
		 public List <Users>
		 findbyName(String username);
		 
	  
  }
 