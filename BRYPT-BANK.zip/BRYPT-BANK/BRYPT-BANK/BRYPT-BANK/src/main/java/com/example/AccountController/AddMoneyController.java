package com.example.AccountController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.Dao.AddMoneyDao;
import com.example.Dao.UserDao;
import com.example.Exception.BankTransactionException;
import com.example.classes.AddMoney;
import com.example.classes.Users;

/*@Controller
public class AddMoneyController {
	
	@Autowired
	private AddMoneyDao addMoneyDAO;
	

	
	@GetMapping("/credit")
	public String show(Model model) {
	AddMoney ben = new AddMoney();
	//model.addAttribute("accountType",accountType);



	model.addAttribute("addMoneyForm", ben);
	return "AddMoney";
	}
	
	@RequestMapping(value = "/credit", method = RequestMethod.POST)
	public String processAddMoney(Model model, AddMoney amt) {
		
		System.out.println("Add Money: " + amt.getAmoot());



	try {
	addMoneyDAO.addMoney(amt.getAccountId(), //
	amt.getAmoot());
	} catch (BankTransactionException e) {
	model.addAttribute("errorMessage", "Error: " + e.getMessage());
	return "/AddMoney";
	}
	return "/AddMoney";
	}
*/
	@Controller
	public class AddMoneyController {
		@Autowired
		private AddMoneyDao addMoneyDAO;
		
		@GetMapping("/credit")
		public String balanceShow(Model model) {
		AddMoney m = new AddMoney(); // model.addAttribute("accountType",accountType); 
		model.addAttribute("addMoneyForm", m);
		return "AddMoney"; 
		}
		@RequestMapping(value = "/credit", method = RequestMethod.POST) public String
		processAddMoney(Model model, AddMoney addMoney ) {

		System.out.println("Add Money: " + addMoney.getAmoot());

		try { 
			addMoneyDAO.addMoney(addMoney.getAccountId(), 
				addMoney.getAmoot()); }
		catch (BankTransactionException e)
		{ model.addAttribute("errorMessage","Error: " + e.getMessage()); 
		
		return "/AddMoney";
		} 
		return "/clientDash";
		}

	}


