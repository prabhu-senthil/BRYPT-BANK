package com.example.Dao;

import org.springframework.stereotype.Repository;
import java.util.List;



import javax.persistence.EntityManager;
import javax.persistence.Query;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;



import com.example.Info.BeneficiaryInfo;
import com.example.Info.UsersInfo;
import com.example.classes.Beneficiary;
import com.example.classes.Users;
import com.example.Exception.BankTransactionException;






@Repository
public class UserDao {



@Autowired
private EntityManager entityManager;





public Users findById(long userId) { 
	return
this.entityManager.find(Users.class, userId); 
	}



public List<UsersInfo> listCustomerInfo() {
String sql = "Select new " + UsersInfo.class.getName() //
+ "(e.userId,e.name,e.email ,e.password,e.gender,e.accountNo,e.dob,e.accountType,e.age,e.address,e.adharNo,e.panNo,e.phoneNo,e.Balance) " //
+ " from " + Users.class.getName() + " e ";
Query query = entityManager.createQuery(sql, UsersInfo.class);

return query.getResultList();
}

/*
 * public Beneficiary findById(Long beneficiaryid) { return
 * this.entityManager.find(Beneficiary.class, beneficiaryid); }
 */


/*
 * public List<BeneficiaryInfo> listBeneficiaryInfo() { String sql =
 * "Select new " + BeneficiaryInfo.class.getName() // +
 * "(e.beneficiaryId,e.beneficiaryName,e.bank ,e.accountNo,e.phoneNo) " // +
 * " from " + Beneficiary.class.getName() + " e "; Query query =
 * entityManager.createQuery(sql, BeneficiaryInfo.class); return
 * query.getResultList(); }
 */




@Transactional
public void addAmount(long userId, double amount) throws BankTransactionException {
/* Beneficiary account =this.findById(beneficiaryId); */
Users acc=this.findById(userId);
if (acc == null) {
throw new BankTransactionException("Account not found " + userId );
}
double newBalance = acc.getBalance() + amount;
if (acc.getBalance() + amount < 0) {
throw new BankTransactionException(
"The money in the account '" + userId + "' is not enough (" + acc.getBalance() + ")");
}
acc.setBalance(newBalance);
}



// Do not catch BankTransactionException in this method.
@Transactional(propagation = Propagation.REQUIRES_NEW,
rollbackFor = BankTransactionException.class)
public void sendMoney(long fromAccountId, long toAccountId, double amount) throws BankTransactionException {



addAmount(toAccountId, amount);
addAmount(fromAccountId, -amount);
}





}

