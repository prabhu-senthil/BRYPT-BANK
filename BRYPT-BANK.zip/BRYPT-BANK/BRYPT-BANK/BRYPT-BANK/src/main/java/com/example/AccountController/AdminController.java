package com.example.AccountController;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping
public class AdminController {
	
	@GetMapping("/")
	public String defaultHome() {
		return "welcome";
	}

	@GetMapping("/login")
	public String login() {
		return "Login";
	}

	@GetMapping("/dashboard")
	public String userDashboard() {
		return "clientDash";
	}

	@GetMapping("/admin/")
	public String admin() {
		return "Login";
	}

	@GetMapping("/admin/login")
	public String adminlogin() {
		return "Login";
	}

	@GetMapping("/admin/dashboard")
	public String admindashboard() {
		return "admindash";
	}

}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * @RequestMapping(value="/", method = RequestMethod.GET) public String home() {
	 * System.out.println("Going home..."); return "welcome"; }
	 * 
	 * 
	 * @RequestMapping("/Index") public ModelAndView index() { return new
	 * ModelAndView("Index"); }
	 * 
	 * @RequestMapping("/admindashboard") public ModelAndView adminDashboard() {
	 * return new ModelAndView("admindash"); }
	 * 
	 * @RequestMapping("/userdashboard") public ModelAndView userDashboard() {
	 * return new ModelAndView("clientDash"); }
	 */
	
	/*
	 * @RequestMapping("/admin/") public ModelAndView admin() { return new
	 * ModelAndView("login"); }
	 * 
	 * @RequestMapping("/admin/login") public ModelAndView adminlogin() { return new
	 * ModelAndView("login"); }
	 * 
	 * @RequestMapping("/admin/dashboard") public ModelAndView admindashboard() {
	 * return new ModelAndView("admin/dashboard"); }
	 */
	

	
	
	/*
	 * @RequestMapping("/admindash")
	 * 
	 * public String admin() {
	 * 
	 * return "admindash";
	 * 
	 * }
	 */
	
	/*
	 * @PostMapping("/admin") public String submitForm( @ModelAttribute("adm") Admin
	 * adm, BindingResult bindingResult, Model model) { admservice.save(adm); return
	 * "redirect:/Admin";
	 * 
	 * 
	 * 
	 * }
	 */
