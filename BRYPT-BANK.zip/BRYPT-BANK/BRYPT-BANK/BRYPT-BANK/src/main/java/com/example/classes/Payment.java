package com.example.classes;

public class Payment {
	  private long accId;
	    private String accountType;
	    
		private Double amot;

	    public Payment() {

	    }
	    public Payment(long accId, String accountType, Double amot) {
			super();
			this.accId = accId;
			this.accountType = accountType;
			this.amot = amot;
		}
		public long getAccId() {
			return accId;
		}
		public void setAccId(long accId) {
			this.accId = accId;
		}
		public String getAccountType() {
			return accountType;
		}
		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}
		public Double getAmot() {
			return amot;
		}
		public void setAmot(Double amot) {
			this.amot = amot;
		}
		

}





