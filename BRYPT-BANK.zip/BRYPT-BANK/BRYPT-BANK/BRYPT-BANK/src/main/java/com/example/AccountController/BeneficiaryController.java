package com.example.AccountController;

import java.util.List;import javax.validation.Valid;import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.example.Services.BeneficiaryService;
import com.example.classes.Beneficiary;@Controller
public class BeneficiaryController {
@Autowired
BeneficiaryService benservice;

@PostMapping("/register")
public String submitForm(@Valid @ModelAttribute("user")
Beneficiary user, BindingResult bindingResult, Model model) {
if (bindingResult.hasErrors())
{
return "regBeneficiary";
}
benservice.save(user);
return "redirect:/benView";
}
@RequestMapping("/benView") public String viewHomePage(Model model)
{
List<Beneficiary> userList = benservice.listAll();
model.addAttribute("list", userList);
return "benReg_sucess";
}
@RequestMapping(value = "/benSave", method = RequestMethod.POST) public String
saveProduct(@ModelAttribute("user") Beneficiary user)
{
benservice.save(user);
return "redirect:/benView";
}
@GetMapping("/register")
public String getbene(Model model)
{
Beneficiary user = new Beneficiary();
model.addAttribute("user", user);
return "regBeneficiary";
}
@RequestMapping("/benEdit/{beneficiaryId}") public String
showEditProductPage(@PathVariable("beneficiaryId") Long beneficiaryId, Model model)
{
Beneficiary user = benservice.get(beneficiaryId);//retrieving only a particular row
model.addAttribute("user", user);
return "editBen";
}
@RequestMapping("/benDelete/{beneficiaryId}") public String
deleteProduct(@PathVariable("beneficiaryId") Long beneficiaryId)
{
benservice.delete(beneficiaryId); return
"redirect:/benView";
}
}
