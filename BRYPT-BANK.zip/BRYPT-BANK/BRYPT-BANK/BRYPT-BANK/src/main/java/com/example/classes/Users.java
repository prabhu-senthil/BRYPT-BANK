package com.example.classes;


import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
//@Table(uniqueConstraints=@UniqueConstraint(columnNames="accountNo"))


public class Users {
	
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private long userId;

	@Email(message = "Please enter a valid e-mail address")
	@NotBlank
	private String username;
	@NotBlank
	private String password;

	private String name;


	private String gender;



	@NotNull
	@Column(name="account_no")
	private long accountNo;



	@Column(name="dob")
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	private Date dob;

	@Column(name="account_type")
	public String accountType ;






	@Column
	private String address;



	@Column
	@Min(value =18)
	@Max(value=100)
	private int age;



	private String ifscCode="BRYPT04CARD";

	@NotNull
	@Column(name="phone_no")
	private long phoneNo;


	private double balance;
	
	@NotNull
	@Column(name="adhar_no")
	private long adharNo;


	@NotNull
	@Column(name="pan_no")
	private String panNo;



	private boolean disabled;
	private boolean accountExpired;
	private boolean accountLocked;
	private boolean credentialsExpired;



	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "user_role",
	joinColumns = @JoinColumn(name = "user_id"),
	inverseJoinColumns = @JoinColumn(name = "role_id"))
	List<Roles> roles;



	public long getUserId() {
		return userId;
	}



	public void setUserId(long userId) {
		this.userId = userId;
	}



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public long getAccountNo() {
		return accountNo;
	}



	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}



	public Date getDob() {
		return dob;
	}



	public void setDob(Date dob) {
		this.dob = dob;
	}



	public String getAccountType() {
		return accountType;
	}



	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public String getIfscCode() {
		return ifscCode;
	}



	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}



	public long getPhoneNo() {
		return phoneNo;
	}



	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}



	public double getBalance() {
		return balance;
	}



	public void setBalance(double balance) {
		this.balance = balance;
	}



	public long getAdharNo() {
		return adharNo;
	}



	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}



	public String getPanNo() {
		return panNo;
	}



	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}



	public boolean isDisabled() {
		return disabled;
	}



	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}



	public boolean isAccountExpired() {
		return accountExpired;
	}



	public void setAccountExpired(boolean accountExpired) {
		this.accountExpired = accountExpired;
	}



	public boolean isAccountLocked() {
		return accountLocked;
	}



	public void setAccountLocked(boolean accountLocked) {
		this.accountLocked = accountLocked;
	}



	public boolean isCredentialsExpired() {
		return credentialsExpired;
	}



	public void setCredentialsExpired(boolean credentialsExpired) {
		this.credentialsExpired = credentialsExpired;
	}



	public List<Roles> getRoles() {
		return roles;
	}



	public void setRoles(List<Roles> roles) {
		this.roles = roles;
	}



	@Override
	public String toString() {
		return "Users [userId=" + userId + ", username=" + username + ", password=" + password + ", name=" + name
				+ ", gender=" + gender + ", accountNo=" + accountNo + ", dob=" + dob + ", accountType=" + accountType
				+ ", address=" + address + ", age=" + age + ", ifscCode=" + ifscCode + ", phoneNo=" + phoneNo
				+ ", balance=" + balance + ", adharNo=" + adharNo + ", panNo=" + panNo + ", disabled=" + disabled
				+ ", accountExpired=" + accountExpired + ", accountLocked=" + accountLocked + ", credentialsExpired="
				+ credentialsExpired + ", roles=" + roles + ", getUserId()=" + getUserId() + ", getUsername()="
				+ getUsername() + ", getPassword()=" + getPassword() + ", getName()=" + getName() + ", getGender()="
				+ getGender() + ", getAccountNo()=" + getAccountNo() + ", getDob()=" + getDob() + ", getAccountType()="
				+ getAccountType() + ", getAddress()=" + getAddress() + ", getAge()=" + getAge() + ", getIfscCode()="
				+ getIfscCode() + ", getPhoneNo()=" + getPhoneNo() + ", getBalance()=" + getBalance()
				+ ", getAdharNo()=" + getAdharNo() + ", getPanNo()=" + getPanNo() + ", isDisabled()=" + isDisabled()
				+ ", isAccountExpired()=" + isAccountExpired() + ", isAccountLocked()=" + isAccountLocked()
				+ ", isCredentialsExpired()=" + isCredentialsExpired() + ", getRoles()=" + getRoles() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}	