package com.example.classes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
	@Table(name = "Beneficiary" )
	public class Beneficiary {

	@Id
	@GeneratedValue
	@Column(name = "beneficiaryid", nullable = false)
	private long beneficiaryId;

	private String beneficiaryName;

	private String bank;

	/* private double balance; */

	private long accountNo;

	private long phoneNo;



	public long getBeneficiaryId() {
	return beneficiaryId;
	}



	public void setBeneficiaryId(long beneficiaryId) {
	this.beneficiaryId = beneficiaryId;
	}



	public String getBeneficiaryName() {
	return beneficiaryName;
	}



	public void setBeneficiaryName(String beneficiaryName) {
	this.beneficiaryName = beneficiaryName;
	}



	public String getBank() {
	return bank;
	}



	public void setBank(String bank) {
	this.bank = bank;
	}



	/*
	* public double getBalance() { return balance; }
	*
	* public void setBalance(double balance) { this.balance = balance; }
	*/
	public long getAccountNo() {
	return accountNo;
	}



	public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
	}



	public long getPhoneNo() {
	return phoneNo;
	}



	public void setPhoneNo(long phoneNo) {
	this.phoneNo = phoneNo;
	}



	@Override
	public String toString() {
	return "Beneficiary [beneficiaryId=" + beneficiaryId + ", beneficiaryName=" + beneficiaryName + ", bank=" + bank
	+ ", accountNo=" + accountNo + ", phoneNo=" + phoneNo + "]";
	}





	}


