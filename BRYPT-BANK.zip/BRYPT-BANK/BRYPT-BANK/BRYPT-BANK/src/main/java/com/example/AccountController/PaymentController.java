package com.example.AccountController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.Dao.PaymentDao;
import com.example.Exception.BankTransactionException;
import com.example.classes.Payment;
@Controller
public class PaymentController {

	@Autowired 
	private PaymentDao paymentDAO;
	@GetMapping("/payment")
	public String show(Model model) {
	Payment benn = new Payment(); //model.addAttribute("accountType",accountType);

	model.addAttribute("billAmountForm", benn);
	return "Bill";
	}
	 
 @RequestMapping(value = "/payment", method = RequestMethod.POST) 
  public String processpayMoney(Model model, Payment payMoney ) {

		System.out.println("pay Money: " + payMoney.getAmot());

		try {
			paymentDAO.PaymentMoney(payMoney.getAccId(), //
					payMoney.getAccountType(), //
					payMoney.getAmot());
		} catch (BankTransactionException e) {
			model.addAttribute("errorMessage", "Error: " + e.getMessage());
			return "billfail";
		}
		return "clientDash";
}

}
