package com.example.Services;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.example.Repository.BeneficiaryRepo;
import com.example.classes.Beneficiary;



@Service
public class BeneficiaryService {

@Autowired
private BeneficiaryRepo benRepo;
public List<Beneficiary> listAll() {
return benRepo.findAll();
}
public void save(Beneficiary user) {
benRepo.save(user);
}
public Beneficiary get(long id) {
return benRepo.findById(id).get();
}
public void delete(long id) {
benRepo.deleteById(id);
}





}
