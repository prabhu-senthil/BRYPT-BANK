package com.example.AccountController;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



import com.example.Dao.BeneficiaryDAO;
import com.example.Dao.UserDao;
import com.example.Info.BeneficiaryInfo;
import com.example.classes.SendMoneyFrom;
import com.example.Exception.BankTransactionException;



@Controller
public class BeneficiaryMainController {

@Autowired
private UserDao customerDAO;

@Autowired
private BeneficiaryDAO beneficiaryDAO;

@RequestMapping(value = "/accounts", method = RequestMethod.GET)
public String showBankAccounts(Model model) {
List<BeneficiaryInfo> list = beneficiaryDAO.listBeneficiaryInfo();



model.addAttribute("accountInfos", list);



return "accountsPage";
}




@RequestMapping(value = "/sendMoney", method = RequestMethod.GET)
public String viewSendMoneyPage(Model model) {



SendMoneyFrom form = new SendMoneyFrom(1L, 2L, 700d);



model.addAttribute("sendMoneyForm", form);



return "sendMoney";
}



@RequestMapping(value = "/sendMoney", method = RequestMethod.POST)
public String processSendMoney(Model model, SendMoneyFrom sendMoneyForm) {



System.out.println("Send Money: " + sendMoneyForm.getAmount());



try {
customerDAO.sendMoney(sendMoneyForm.getFromAccountId(), //
sendMoneyForm.getToAccountId(), //
sendMoneyForm.getAmount());
} catch (BankTransactionException e) {
model.addAttribute("errorMessage", "Error: " + e.getMessage());
return "/sendMoney";
}
return "clientDash";
}
}
