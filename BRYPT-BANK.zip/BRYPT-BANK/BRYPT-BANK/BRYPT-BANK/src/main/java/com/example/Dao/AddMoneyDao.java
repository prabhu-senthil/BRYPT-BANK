package com.example.Dao;
  
  import java.util.List;
  
  import javax.persistence.EntityManager; import javax.persistence.Query;
  
  import org.springframework.beans.factory.annotation.Autowired; import
  org.springframework.stereotype.Repository; import
  org.springframework.transaction.annotation.Propagation; import
  org.springframework.transaction.annotation.Transactional;

import com.example.Exception.BankTransactionException;
import com.example.Info.UsersInfo;
import com.example.classes.Users;
  
 
 /* @Repository public class AddMoneyDao {
  
  @Autowired private EntityManager entityManager;
  
  
  public AddMoneyDao() { }
  
  public Users findById(long userId) { return
  this.entityManager.find(Users.class, userId); }
  
  public List<UsersInfo> listCustomerInfo() {
		String sql = "Select new " + UsersInfo.class.getName() //
				+ "(e.id,e.name,e.email ,e.password,e.gender,e.accountNo,e.dob,e.accountType,e.age,e.address,e.adharNo,e.panNo,e.phoneNo,e.Balance) " //
				+ " from " + Users.class.getName() + " e ";
		Query query = entityManager.createQuery(sql, UsersInfo.class);
		return query.getResultList();
	}
  

 * public Beneficiary findById(Long beneficiaryid) { return
 * this.entityManager.find(Beneficiary.class, beneficiaryid); }
 * 
 * public List<BeneficiaryInfo> listBeneficiaryInfo() { String sql =
 * "Select new " + BeneficiaryInfo.class.getName() // +
 * "(e.beneficiaryId,e.beneficiaryName,e.bank ,e.accountNo,e.phoneNo) " // +
 * " from " + Beneficiary.class.getName() + " e "; Query query =
 * entityManager.createQuery(sql, BeneficiaryInfo.class); return
 * query.getResultList(); }
 
  
  @Transactional(propagation = Propagation.MANDATORY ) public void
  addAmount(long userId, double amo) throws BankTransactionException {
		 Beneficiary account =this.findById(beneficiaryId); 
  Users acc=this.findById(userId); if (acc == null) { throw new
  BankTransactionException("Account not found " +userId ); } double
newBalance = acc.getBalance() + amo; 
  
										 * if (acc.getBalance() + amount < 0) { throw new BankTransactionException(
										 * "The money in the account '" + id + "' is not enough (" + acc.getBalance() +
										 * ")"); } 

  acc.setBalance(newBalance);
										
  }
  
  // Do not catch BankTransactionException in this method.
  
  @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor =
  BankTransactionException.class)
  public void addMoney(long accountId, double amo) throws BankTransactionException {
  
  
  addAmount(accountId, amo); }
  */
@Repository public class AddMoneyDao {
	  
	  @Autowired private EntityManager entityManager;
	  
	  
	  public AddMoneyDao() {
		  
	  }
	  
	  public Users findById(long user_id) { return
	  this.entityManager.find(Users.class, user_id); }
	  
	  public List<UsersInfo> listCustomerInfo() {
			String sql = "Select new " + UsersInfo.class.getName() //
					+ "(e.id,e.name,e.email ,e.password,e.gender,e.accountNo,e.dob,e.accountType,e.age,e.address,e.adharNo,e.panNo,e.phoneNo,e.balance) " //
					+ " from " + Users.class.getName() + " e ";
			Query query = entityManager.createQuery(sql, UsersInfo.class);
			return query.getResultList();
		}
	  
	/*
	 * public Beneficiary findById(Long beneficiaryid) { return
	 * this.entityManager.find(Beneficiary.class, beneficiaryid); }
	 * 
	 * public List<BeneficiaryInfo> listBeneficiaryInfo() { String sql =
	 * "Select new " + BeneficiaryInfo.class.getName() // +
	 * "(e.beneficiaryId,e.beneficiaryName,e.bank ,e.accountNo,e.phoneNo) " // +
	 * " from " + Beneficiary.class.getName() + " e "; Query query =
	 * entityManager.createQuery(sql, BeneficiaryInfo.class); return
	 * query.getResultList(); }
	 */
	  
	  @Transactional(propagation = Propagation.MANDATORY ) public void
	  addAmount(long user_id, double amoot) throws BankTransactionException {
			/* Beneficiary account =this.findById(beneficiaryId); */
	  Users acc=this.findById(user_id); 
	  if (acc == null) { throw new
	  BankTransactionException("Account not found " +acc.getAccountNo() );
	  }
	  double newBalance = acc.getBalance() + amoot;
	  acc.setBalance(newBalance);
	  }
	  
	  
	/*  if (acc.getBalance() + amountt < 0) {
	  throw new BankTransactionException( "The money in the account '" + user_id +
	  "' is not enough (" + acc.getBalance() + ")"); } acc.setBalance(newBalance);
	  }*/
	  
	  // Do not catch BankTransactionException in this method.
	  
	  @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = BankTransactionException.class)
	  public void addMoney(long account_id, double amoot) throws BankTransactionException {
	  
	  
	  addAmount(account_id,amoot); 
	  
	  }

  }