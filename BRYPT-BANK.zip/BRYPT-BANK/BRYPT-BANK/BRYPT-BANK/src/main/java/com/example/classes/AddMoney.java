package com.example.classes;

public class AddMoney {
	private long accountId;
    
    private Double amoot;

    public AddMoney() {

    }

	public AddMoney(long accountId, Double amoot) {
		super();
		this.accountId = accountId;
		this.amoot = amoot;
	}

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public Double getAmoot() {
		return amoot;
	}

	public void setAmoot(Double amoot) {
		this.amoot = amoot;
	}
   
	



	
	
}

  
