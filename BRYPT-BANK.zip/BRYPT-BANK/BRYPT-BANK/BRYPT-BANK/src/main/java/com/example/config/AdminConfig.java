package com.example.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
@Order(1)
public class AdminConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;
	
	
	@Autowired
	UserDetailsService adminDetailsServiceImpl;
	
	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(adminDetailsServiceImpl).passwordEncoder(bCryptPasswordEncoder);

		// Use this code for inmemeory database authentication
		//auth.inMemoryAuthentication()
		//	.withUser("admin").password("{noop}password").roles("ADMIN");
	}

	@Override
	public void configure(HttpSecurity http) throws Exception {
		http
		.authorizeRequests().antMatchers("/admin",
                "/js/**",
                "/css/**",
                "/img/**").permitAll().and()
		.antMatcher("/admin/**")
		.authorizeRequests().anyRequest().authenticated()
			.and().formLogin().loginPage("/admin/login")
				.defaultSuccessUrl("/admin/dashboard", true)
				.failureUrl("/admin/login?adminerror=true")
			.permitAll()
			.and().logout().logoutUrl("/admin/logout").logoutSuccessUrl("/logout");
		http.csrf().disable();

			
			/*.authorizeRequests().antMatchers("/**").permitAll()
			.and().formLogin()
				.defaultSuccessUrl("/admindashboard", true)
				.failureUrl("/Index?adminerror=true")
			.permitAll()
			.and().logout().logoutUrl("/Index").logoutSuccessUrl("/Index");
		http.csrf().disable();
*/
				/*
				 * .authorizeRequests().antMatchers("/admindashboard").authenticated()
				 * .anyRequest().permitAll() .and() .formLogin() .usernameParameter("username")
				 * .defaultSuccessUrl("/admindashboard") .permitAll() .and()
				 * .logout().logoutSuccessUrl("/Index").permitAll() .and() .httpBasic() .and()
				 * .csrf().disable();
				 */
		 /*.authorizeRequests().antMatchers("/**").permitAll()
		.and().formLogin().loginPage("/Index").usernameParameter("username").passwordParameter("password")
		.defaultSuccessUrl("/admindash", true) .failureUrl("/login?usererror=true")
		.permitAll() .and().logout().logoutSuccessUrl("/Index");
		http.csrf().disable();
		*/
	}	
}

