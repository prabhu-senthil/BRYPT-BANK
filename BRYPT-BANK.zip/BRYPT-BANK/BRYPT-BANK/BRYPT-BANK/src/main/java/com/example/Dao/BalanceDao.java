package com.example.Dao;

import java.util.List;

import javax.persistence.EntityManager;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.Exception.BankTransactionException;
import com.example.Info.UsersInfo;
import com.example.classes.Users;

import javax.persistence.Query;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;



@Repository 
public class BalanceDao {
	
	 @Autowired 
	  private EntityManager entityManager;
	  
	  double newBal;
	  
	  public BalanceDao() { 
		  
	  }
	  public Users findById(long user_id) { return
			  this.entityManager.find(Users.class, user_id); }

	public List<UsersInfo> listCustomerInfo() {
		String sql = "Select new " + UsersInfo.class.getName() //
				+ "(e.id,e.name,e.email ,e.password,e.gender,e.accountNo,e.dob,e.accountType,e.age,e.address,e.adharNo,e.panNo,e.phoneNo,e.balance) " //
				+ " from " + Users.class.getName() + " e ";
		Query query = entityManager.createQuery(sql, UsersInfo.class);
		return query.getResultList();
	}
	
	@Transactional(propagation = Propagation.MANDATORY )
	public void addAmount(long bankAccountId) throws BankTransactionException {
		/* Beneficiary account =this.findById(beneficiaryId); */
		Users acc=this.findById(bankAccountId);
		if (acc == null) {
			throw new BankTransactionException("Account not found " + bankAccountId );
		}
		double newBalance = acc.getBalance();
		
		newBal=newBalance;
	}
		/*
		 * if (acc.getBalance() + amo < 0) { throw new BankTransactionException(
		 * "The money in the account '" + accountNo + "' is not enough (" +
		 * acc.getBalance() + ")"); } acc.setBalance(newBalance);
		 */
	
	public double getnewBal() {
	return newBal;
	}
	
	 @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor =BankTransactionException.class) 
	  public void BalanceMoney(long bankAccountId) throws BankTransactionException {
	  
	  
	  addAmount(bankAccountId); }
	  
	  }	



