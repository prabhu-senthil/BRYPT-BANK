package com.example.AccountController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.Dao.BalanceDao;
import com.example.Exception.BankTransactionException;
import com.example.classes.Balance;
@Controller
public class BalanceController {
	@Autowired
    private BalanceDao balanceDAO;	

@GetMapping("/balance")
	  public String show(Model model) { 
		  Balance b = new Balance(); //model.addAttribute("accountType",accountType);
	  
	  model.addAttribute("balanceForm", b); 
	  return "Balance";
	 
	  }



 @RequestMapping(value = "/balance", method = RequestMethod.POST) 
  public String processpayMoney(Model model, Balance balMoney ) {

		System.out.println("bal Money: " + balMoney.getBankAccountId());

		try {
			balanceDAO.BalanceMoney(balMoney.getBankAccountId());
		} catch (BankTransactionException e) {
			model.addAttribute("errorMessage", "Error: " + e.getMessage());
			return "Balance";
		}
		 double balance;
		 balance=balanceDAO.getnewBal();
		 model.addAttribute("balance",balance);
		return "ShowBalance";
  }

}
