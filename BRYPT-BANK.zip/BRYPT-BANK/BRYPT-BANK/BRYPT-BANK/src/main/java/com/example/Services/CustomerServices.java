
  package com.example.Services;
  
  import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import
  org.springframework.stereotype.Service;
  
  import com.example.Repository.CustomerRepository;
import com.example.Repository.UsersRepository;
import com.example.classes.Users;
  
  @Service 
  public class CustomerServices {
  
  @Autowired
  private CustomerRepository repo;
  
 
// BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
	  
	 public List<Users> listAll() {
		return repo.findAll();
	}
	
	public void save(Users cust) {
		//cust.setPassword(encoder.encode(cust.getPassword()));
		repo.save(cust);
	}
	
	public Users get(long userId) {
		return repo.findById(userId).get();
	}
	
	public void delete(long userId) {
		repo.deleteById(userId);
	}

	public List<Users> search(String email) {
		  return repo.findbyName(email);
		  
		  }

	public void saves(Users users) {
		//cust.setPassword(encoder.encode(cust.getPassword()));
		repo.save(users);
  
  
  }
  }
  
 